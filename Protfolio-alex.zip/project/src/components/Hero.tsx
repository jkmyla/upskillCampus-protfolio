import React from 'react';
import { ChevronDown, Github, Linkedin, Mail } from 'lucide-react';

const Hero = () => {
  const scrollToAbout = () => {
    const aboutSection = document.querySelector('#about');
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-black"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.1)_0%,transparent_50%)]"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center">
          <div className="mb-8">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              Hi, I'm <span className="text-green-400 bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">Alex</span>
            </h1>
            <div className="text-xl md:text-2xl text-gray-300 mb-8">
              <span className="block mb-2">Full Stack Developer</span>
              <span className="text-green-400">Building Digital Experiences</span>
            </div>
          </div>

          <p className="text-lg text-gray-400 max-w-2xl mx-auto mb-12 leading-relaxed">
            I create modern, responsive web applications with clean code and beautiful design. 
            Passionate about turning ideas into reality through technology.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
            <button className="bg-green-500 hover:bg-green-600 text-white px-8 py-4 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-green-500/25">
              View My Work
            </button>
            <button className="border-2 border-green-400 text-green-400 hover:bg-green-400 hover:text-black px-8 py-4 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105">
              Download Resume
            </button>
          </div>

          <div className="flex items-center justify-center space-x-8 mb-16">
            <a href="#" className="text-gray-400 hover:text-green-400 transition-colors duration-200 transform hover:scale-110">
              <Github size={28} />
            </a>
            <a href="#" className="text-gray-400 hover:text-green-400 transition-colors duration-200 transform hover:scale-110">
              <Linkedin size={28} />
            </a>
            <a href="#" className="text-gray-400 hover:text-green-400 transition-colors duration-200 transform hover:scale-110">
              <Mail size={28} />
            </a>
          </div>

          <button 
            onClick={scrollToAbout}
            className="text-green-400 hover:text-green-300 transition-colors duration-200 animate-bounce"
          >
            <ChevronDown size={32} />
          </button>
        </div>
      </div>
    </section>
  );
};

export default Hero;